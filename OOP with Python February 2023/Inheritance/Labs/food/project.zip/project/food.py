class Food:
    def __init__(self, expiration_date: str):
        self.expiration_date = expiration_date
